-- CRIAÇÃO DA TABELA DE PROPRIETÁRIOS (CLIENTES)
create database dbo;
use dbo;

CREATE TABLE dbo.tb_Clientes(
	Id_Cliente int NOT NULL,
	Id_Cliente_Plano int NULL,
	Nome_Cliente varchar(50) NULL,
	Nome_Abreviado varchar(40) NULL,
	Categoria_Pessoa varchar(10) NULL,
	Tipo_Cliente int NULL,
	data_nascimento datetime NULL,
	sexo char (1) NULL,
	rg varchar(15) NULL,
	orgao_expedidor varchar(15) NULL,
	cpf_cnpj varchar(15) NULL,
	nome_pai varchar(50) NULL,
	nome_mae varchar(50) NULL,
	Endereco varchar(40) NULL,
	Numero varchar(6) NULL,
	Complemento varchar(15) NULL,
	Bairro varchar(30) NULL,
	Cidade varchar(60) NULL,
	sigla_uf varchar(2) NULL,
	cep varchar(10) NULL,
	ddd1 varchar(4) NULL,
	telefone1 varchar(10) NULL,
	ddd2 varchar(4) NULL,
	telefone2 varchar(10) NULL,
	ddd_fax varchar (4) NULL,
	numero_fax varchar(10) NULL,
	e_mail varchar(75) NULL,
	inscricao_estadual varchar(20) NULL,
	inscricao_municipal varchar(20) NULL,
	cliente_desde datetime NULL,
	contato varchar(40) NULL,
	observacao varchar(300) NULL,
	situacao_cliente char(1) NULL,
	IdUltima_fichaAtendimento int NULL,
	AtualizadoFinanceiro bit NULL,
	codigo_contabil varchar(16) NULL,
	contabilizacao varchar(15) NULL,
	endereco_cobranca varchar(50) NULL,
	complemento_cobranca varchar(30) NULL,
	bairro_cobranca varchar(30) NULL,
	cidade_cobranca varchar(30) NULL,
	sigla_uf_cobranca varchar(2) NULL,
	CEP_cobranca varchar(9) NULL,
	telefone_cobranca varchar(20) NULL,
	fax_cobranca varchar(20) NULL,
	Integracao_Cupom varchar(1) NULL,
	Integracao_Site varchar(1) NULL,
	Total_Atend int NULL,
	Credito_Cliente DOUBLE NULL,
	cod_Cidade int NULL,
	id_pais int NULL,
	dia_vencto tinyint NOT NULL,
	EnviarDocE_Pdf bit NULL,
	EnviarDocE_Xml bit NULL,
	possui_retencao_pis bit NULL,
	possui_retencao_cofins bit NULL,
	possui_retencao_csll bit NULL,
	possui_retencao_issqn bit NULL,
	vlr_limite_isencao_pis_cofins DOUBLE NULL,
	Id_Cliente_Antigo int NULL,
	requer_confirmacao_cadastro bit NOT NULL,
	dt_confirmacao_cadastro datetime NULL,
	id_operador_confirmacao_cadastro int NULL,
	id_cliente_integracao_externa int NULL,
	CentroCusto_Integracao varchar(100) NULL,
	RegimeContabil int NULL,
	Possui_Retencao_IRRF bit NULL,
	Id_Empresa_Origem_Cliente int NULL,
	data_inclusao_confirmacao datetime NULL,
	Possui_Retencao_INSS bit NULL,
	Id_Logradouro int NULL,
	Id_OrigemCliente int NOT NULL,
	Inscr_Estadual_Isenta bit NULL,
 CONSTRAINT PK_tb_Clientes PRIMARY KEY CLUSTERED (Id_Cliente ASC)
 );
 
 -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON PRIMARY) ON PRIMARY GO


-- CRIAÇÃO DA TABELA DE ANIMAIS
CREATE TABLE dbo.tb_Animais(
	Id_Animal int NOT NULL,
	Id_Cliente int NOT NULL,
	Nome_Animal varchar(30) NOT NULL,
	Data_Nascimento datetime NOT NULL,
	Sexo varchar(6) NULL,
	Id_especie int NOT NULL,
	Id_porte int NOT NULL,
	Id_raca int NOT NULL,
	Id_pelagem int NOT NULL,
	Codigo_Barras varchar(13) NULL,
	Pedigree varchar(20) NULL,
	Id_Temperamento int NULL,
	Data_Obito datetime NULL,
	Id_motivo_obito int NULL,
	Observacao varchar(300) NULL,
	Microchip varchar(20) NULL,
	Fotografia  VARCHAR(100) NULL,
	Ultima_Ficha_Atend int NULL,
	Data_Ultima_Ficha datetime NULL,
	Status_Ultima_Ficha int NULL,
	Integracao_Site varchar(1) NULL,
	Id_Animal_Antigo int NULL,
	requer_confirmacao_cadastro bit NOT NULL,
	dt_confirmacao_cadastro datetime NULL,
	id_operador_confirmacao_cadastro int NULL,
	Id_Protocolo int NULL,
	Temperamento int NULL,
	Castrado int NULL,
	Doador_Sangue int NULL,
	Localizacao_Animal varchar(255) NULL,
	Cidade_Localizacao_Animal varchar(60) NULL,
	UF_Localizacao_Animal varchar(3) NULL,
	LocalizacaoAnimalDiferenteProprietario bit NULL,
 CONSTRAINT PK_tb_Animais PRIMARY KEY CLUSTERED (Id_Animal ASC)
 );
-- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON PRIMARY) ON PRIMARY TEXTIMAGE_ON PRIMARY GO

-- CRIAÇÃO DA TABELA DE ESPECIE DE ANIMAIS
CREATE TABLE dbo.tb_Especie(
	Id_Especie int NOT NULL,
	Descricao varchar(40) NOT NULL,
	Registro_Fixo bit NULL,
	Classificacao int NULL,
 CONSTRAINT PK_tb_Especie PRIMARY KEY CLUSTERED (	Id_Especie ASC)
 );
 
 -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON PRIMARY) ON [PRIMARY GO

-- CRIAÇÃO DA TABELA DE PORTE DE ANIMAIS
CREATE TABLE dbo.tb_Porte(
	Id_Porte int NOT NULL,
	Descricao varchar(40) NOT NULL,
	Registro_Fixo bit NULL,
	Peso_De float NULL,
	Peso_Ate float NULL,
 CONSTRAINT PK_tb_porte PRIMARY KEY CLUSTERED(Id_Porte ASC)
 );
 
 -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON PRIMARY) ON PRIMARY GO

-- CRIAÇÃO DA TABELA DE RAÇA DE ANIMAIS
CREATE TABLE dbo.tb_Raca(
	Id_Raca int NOT NULL,
	Id_Especie int NOT NULL,
	Descricao varchar(40) NOT NULL,
	Registro_Fixo bit NULL,
	GeraRacaVertis bit NOT NULL,
	id_porte_aux int NULL,
 CONSTRAINT PK_tb_raca PRIMARY KEY CLUSTERED (Id_Raca ASC)
 );
 -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON PRIMARY) ON PRIMARY GO


-- CRIAÇÃO DA TABELA DE PELAGEM DOS ANIMAIS
CREATE TABLE dbo.tb_Pelagem( 
	Id_Pelagem int NOT NULL,
	Descricao varchar(40) NOT NULL,
 CONSTRAINT PK_tb_pelagem PRIMARY KEY CLUSTERED (Id_Pelagem ASC)
 );
 -- WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90) ON PRIMARY) ON PRIMARY GO


-- TABELA CLIENTE --
insert into tb_clientes values
(2, 20, "nomeCliente", "abreviacao", "categoria", 2, "2022/02/20", 'M', "rg", "orgao", "cpf", "nomepai", "nomemae", "endereco", "numero",
"complemento", "bairo", "cidade", "UF", "cep", "ddd", "telefone1", "dddd", "telefone2", "dfax", "llllllllll", "email", "incricaoEstadual",
"inscricaoMunicipal", "2020/2/15", "contato", "observacao", 'N', 2, 1, "codigoContabil", "contabilizacao", "enderecoCobranca", "completometoCobranca",
"bairroCobranca", "cidadeCobranca", "UF", "cep", "telefoneCobranca", "faxCobranca", "C", "S", 3,
12.62, 1, 1, 1, 1,1 , 1, 1, 1, 1, 2.69, 1, 1, "2023/2/8", 1,1,"centroCusto", 1, 1, 1, "2022/5/6", 1,  1, 1, 1);

select * from tb_clientes;

-- TABELA ANIMAIS --
insert into tb_animais value
(1,1,"nomeAnimal", "2023/2/2", "sexo", 1, 1,1,1, "codigoBarra", "pedigree", 1, "2022/2/2", 1, "observacao", "microchip", "fotografia", 1, 
"2020/2/2", 1, "I", 1, 1, "2020/2/2", 1,1,1,1,1,"localizacaoAnimal", "cidadeLocalizaoAnimal", "AOP", 1);

select * from tb_animais;

-- TABELA ESPECIE --
insert into tb_especie value 
(2, "descricao", 1, 2);

select * from tb_especie;


-- TABELA PORTE --
insert into tb_Porte values 
(3, "descricao", 1, 6.3, 6.3);

select * from tb_Porte;

-- TABELA RACA --
insert into tb_raca values
(1,1,"descricao",1,1,2);

 select * from tb_Raca;
 
 -- TABELA PELAGEM --
 insert into tb_Pelagem values
 (1, "descricao");
 
 select * from tb_Pelagem;