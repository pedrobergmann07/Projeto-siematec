﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using MySql.Data.MySqlClient;
using System.Security.Cryptography;
using CadatroCliente;

namespace CadatroCliente
{
    class ConexaoBD
    {

        private MySqlConnection conexao;

        public void ConectarBD()
        {
            conexao = new MySqlConnection("Persist Security Info = false; " +
                                            "server = localhost; " +
                                            "database = dbo; " +
                                            "uid = root; pwd=;SslMode=none");
            conexao.Open();
        }

        public void AlterarTabelas(string sql)
        {
            ConectarBD();

            MySqlCommand comandos = new MySqlCommand(sql, conexao);
            comandos.ExecuteNonQuery();
            conexao.Close();
        }

        public DataTable ConsultarTabelas(string sql)
        {
            ConectarBD();
            MySqlDataAdapter consulta = new MySqlDataAdapter(sql, conexao);
            DataTable resultado = new DataTable();
            consulta.Fill(resultado);
            conexao.Close();
            return resultado;
        }
    }











}


       

        

