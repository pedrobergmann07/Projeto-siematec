using System.Xml.Linq;
using CadatroCliente;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static CadatroCliente.ConexaoBD;

namespace CadatroCliente
{
    public partial class Form1 : Form
    {

        ConexaoBD bd = new ConexaoBD();

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_Localizar_Click(object sender, EventArgs e)
        {

            string sql = string.Format("select * from clientes where codigo = '{0}' or cpf = '{1}' ", txt_Codigo.Text, txt_Cpf.Text);

            if (dtg_Listar.SelectedRows[0].Index > 0)
            {
                txt_Codigo.Text = dtg_Listar.SelectedRows[1].Index.ToString();
                txt_Cpf.Text = dtg_Listar.SelectedRows[2].Index.ToString();
                cmbx_Categoria.Text = dtg_Listar.SelectedRows[3].Index.ToString();
                txt_Primeironome.Text = dtg_Listar.SelectedRows[4].Index.ToString();
                txt_Nome.Text = dtg_Listar.SelectedRows[5].Index.ToString();
                dtp_Datanasc.Text = dtg_Listar.SelectedRows[6].Index.ToString();
                cmbx_Sexo.Text = dtg_Listar.SelectedRows[7].Index.ToString();
                txtRg.Text = dtg_Listar.SelectedRows[8].Index.ToString();
                txt_Orgaoexp.Text = dtg_Listar.SelectedRows[9].Index.ToString();
                txt_Nomedamae.Text = dtg_Listar.SelectedRows[10].Index.ToString();
                txt_Nomedopai.Text = dtg_Listar.SelectedRows[11].Index.ToString();
                txt_Cep.Text = dtg_Listar.SelectedRows[12].Index.ToString(); 
                cmbx_Uf.Text = dtg_Listar.SelectedRows[13].Index.ToString();
                cmbx_Cidade.Text = dtg_Listar.SelectedRows[14].Index.ToString();
                cmbx_Endereco.Text = dtg_Listar.SelectedRows[15].Index.ToString();
                txt_Numeroendereco.Text = dtg_Listar.SelectedRows[16].Index.ToString();
                txt_Complemento.Text = dtg_Listar.SelectedRows[17].Index.ToString();
                txt_Bairro.Text = dtg_Listar.SelectedRows[18].Index.ToString();
                cmbx_Pais.Text = dtg_Listar.SelectedRows[19].Index.ToString();
                dtp_Clientedesde.Text = dtg_Listar.SelectedRows[20].Index.ToString();
                txt_Foneresidencial.Text = dtg_Listar.SelectedRows[21].Index.ToString();
                txt_Fonecomercial.Text = dtg_Listar.SelectedRows[22].Index.ToString();
                txt_celular.Text = dtg_Listar.SelectedRows[23].Index.ToString();
                txt_Email.Text = dtg_Listar.SelectedRows[24].Index.ToString();
            }
            else
            {
                MessageBox.Show("Cliente N�o esta cadastrado no sistema!", "clientes", MessageBoxButtons.OK);
            }
        }

        private void btn_Excluir_Click(object sender, EventArgs e)
        {
            string sql = string.Format("delete from tb_animais where Id_animal = '{0}'", txt_Codigo.Text);
            
            bd.AlterarTabelas(sql);
            MessageBox.Show("Dados do Animal exclu�dos com sucesso! ", "Animais", MessageBoxButtons.OK);
            
            limpar();
            listar();
        }

        private void limpar()
        {
            txtRg.Clear();
            txtRuaendereco.Clear();
            txt_Bairro.Clear(); 
            txt_celular.Clear();
            txt_Cep.Clear();
            txt_Codigo.Clear();
            txt_Complemento.Clear();
            txt_Cpf.Clear();
            txt_Dddcelular.Clear();
            txt_Dddcomercial.Clear();
            txt_Dddresidencial.Clear();
            txt_Email.Clear();
            txt_Fonecomercial.Clear();
            txt_Foneresidencial.Clear();
            txt_Nome.Clear();
            txt_Nomedamae.Clear();
            txt_Nomedopai.Clear();
            txt_Numeroendereco.Clear();
            txt_Orgaoexp.Clear();
            txt_Primeironome.Clear();
            
            cmbx_Categoria.Items.Clear();
            cmbx_Cidade.Items.Clear();
            cmbx_Endereco.Items.Clear();
            cmbx_Pais.Items.Clear();
            cmbx_Sexo.Items.Clear();
            cmbx_Uf.Items.Clear();

        }

        private void listar()
        {
            List<string> lista = new List<string>();
            foreach (string s in lista)
            {
                lista.Add(s);
            }

        }

        private void btn_Visualizar_Click(object sender, EventArgs e)
        {
            string sql = "select * from clientes";
            dtg_Listar.DataSource = bd.ConsultarTabelas;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listar();
        }

        private void btn_Incluir_Click(object sender, EventArgs e)
        {
            DateTime data = new DateTime();
            data = DateTime.Parse(dtp_Datanasc.Text);


            string sql = string.Format("insert into clientes values(2,'{0}', {1}', {2}', {3}', {4}', {5}', {6}', {7}', {8}', {9}', {10}',{11}',{12}',{13}',{14}',{15}', {16}',{17}',{18}',{19}', {20}', {21}', {22}', '{23}')"
                , txt_Codigo.Text, txt_Cpf.Text, cmbx_Categoria.Text, txt_Primeironome.Text, txt_Nome.Text, dtp_Datanasc.ToString, cmbx_Sexo.Text, txtRg.Text, txt_Orgaoexp.Text, txt_Nomedopai.Text, txt_Nomedamae.Text, txt_Cep.Text, 
                cmbx_Uf.Text, cmbx_Cidade.Text, txtRuaendereco.Text, txt_Numeroendereco.Text, txt_Complemento.Text, txt_Bairro.Text, cmbx_Pais.Text, dtp_Clientedesde.ToString, txt_Foneresidencial.Text, txt_Fonecomercial.Text, txt_celular.Text, txt_Email.Text);

            bd.AlterarTabelas(sql);
            MessageBox.Show("Cliente inserido com sucesso!", "Clientes", MessageBoxButtons.OK);
            
            limpar();
            listar();
        }

        private void btn_Alterar_Click(object sender, EventArgs e)
        {
            DateTime data = new DateTime();
            data = DateTime.Parse(dtp_Datanasc.Text);
            string sql = string.Format("update clientes set codigo = '{0}', cpf  = '{1}', categoria = '{2}', primeiro nome = '{3}', nome = '{4}', data nasc = '{5}', sexo = '{6}', RG = '{7}', orgao exp = '{8}', nome do pai = '{9}', nome da mae = '{10}', CEP = '{11}', UF = '{12}', cidade = '{13}', endereco = '{14}', numero = '{15}', complemento = '{16}', bairro = '{17}', pais = '{18}', cliente desde = '{19}', fone residencial = '{20}', fone comercial = '{21}', celular = '{22}', e-mail = '{23}' "
                ,txt_Codigo.Text, txt_Cpf.Text, cmbx_Categoria.Text, txt_Primeironome.Text, txt_Nome.Text, dtp_Datanasc.ToString, cmbx_Sexo.Text, txtRg.Text, txt_Orgaoexp.Text, txt_Nomedopai.Text, txt_Nomedamae.Text, txt_Cep.Text, cmbx_Uf.Text, cmbx_Cidade.Text, cmbx_Endereco.Text, txt_Numeroendereco.Text, txt_Complemento.Text, txt_Bairro.Text, cmbx_Pais.Text, dtp_Clientedesde.ToString, 
                txt_Fonecomercial.Text, txt_Foneresidencial.Text, txt_celular.Text, txt_Email.Text);

            bd.AlterarTabelas(sql);
            MessageBox.Show("Aluno alterado com sucesso!", "clientes", MessageBoxButtons.OK);
            
            limpar();
            listar();
        }

        private void btn_Gravar_Click(object sender, EventArgs e)
        {
            int linha = dtg_Listar.SelectedRows[0].Index;
            string queryAtualizarClientes = string.Format(@"UPDATE tb_clientes SET codigo='{0}' WHERE codigo ='{1}'", txt_Codigo.Text);
            ConexaoBD.ReferenceEquals(queryAtualizarClientes,txt_Codigo.Text);
            dtg_Listar[0, linha].Value = txt_Codigo.Text;
            MessageBox.Show("dados gravados");

            int animal = dtg_Listar.SelectedRows[1].Index;
            string queryAtualizarClientes2 = string.Format(@"UPDATE tb_animal SET nome_animal = '{0}', sexo = '{1}' WHERE id_animal = '{3}'", txt_Nome.Text, cmbx_Sexo.Text);
            ConexaoBD.ReferenceEquals(queryAtualizarClientes2, txt_Nome.Text);
            ConexaoBD.ReferenceEquals(queryAtualizarClientes2, cmbx_Sexo.Text);
            dtg_Listar[1, animal].Value = txt_Nome.Text;
            dtg_Listar[2, animal].Value = cmbx_Sexo.Text;

            int especie = dtg_Listar.SelectedRows[3].Index;
            string queryAtualizarClientes3 = string.Format(@"UPDATE tb_especie SET descricao = '{0}' WHERE  id_especie = '{1}'", txt_Foneresidencial.Text);
            ConexaoBD.ReferenceEquals(queryAtualizarClientes, txt_Foneresidencial.Text);
            dtg_Listar[3, especie].Value = txt_Foneresidencial.Text;

            int porte = dtg_Listar.SelectedRows[4].Index;
            string queryAtualizarClientes4 = string.Format(@"UPDATE tb_porte SET descricao = '{0}' WHERE id_porte = '{1}'", txt_Nomedamae.Text);
            ConexaoBD.ReferenceEquals(queryAtualizarClientes, txt_Nomedamae.Text);
            dtg_Listar[4, porte].Value = txt_Nomedamae.Text;

            int raca = dtg_Listar.SelectedRows[5].Index;
            string queryAtualizarClientes5 = string.Format(@"UPDATE tb_raca SET descricao = '{0}'; WHERE  id_raca = '{1}'", txt_Nomedopai.Text);
            ConexaoBD.ReferenceEquals(queryAtualizarClientes, txt_Nomedopai.Text);
            dtg_Listar[5, linha].Value = txt_Nomedopai.Text;
        }

        private void btn_Sair_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_Cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dtg_Listar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_Codigo.Text = dtg_Listar.Rows[e.RowIndex].Cells[0].Value.ToString();
            txt_Nome.Text = dtg_Listar.Rows[e.RowIndex].Cells[1].Value.ToString();
            cmbx_Sexo.Text = dtg_Listar.Rows[e.RowIndex].Cells[2].Value.ToString();
            txt_Foneresidencial.Text = dtg_Listar.Rows[e.RowIndex].Cells[3].Value.ToString();
            txt_Nomedamae.Text = dtg_Listar.Rows[e.RowIndex].Cells[4].Value.ToString();
            txt_Nomedopai.Text = dtg_Listar.Rows[e.RowIndex].Cells[5].Value.ToString();
        }

    }
}
