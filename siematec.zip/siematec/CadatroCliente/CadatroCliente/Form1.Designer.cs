﻿namespace CadatroCliente
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Nomecliente = new System.Windows.Forms.Label();
            this.lbl_Cpf = new System.Windows.Forms.Label();
            this.lbl_Codigo = new System.Windows.Forms.Label();
            this.lbl_Categoria = new System.Windows.Forms.Label();
            this.lbl_Primeironome = new System.Windows.Forms.Label();
            this.lbl_Nome = new System.Windows.Forms.Label();
            this.lbl_Datanasc = new System.Windows.Forms.Label();
            this.lbl_Sexo = new System.Windows.Forms.Label();
            this.lbl_Rg = new System.Windows.Forms.Label();
            this.lbl_Orgaoexp = new System.Windows.Forms.Label();
            this.lbl_Nomedopai = new System.Windows.Forms.Label();
            this.lbl_Nomedamae = new System.Windows.Forms.Label();
            this.lbl_Cep = new System.Windows.Forms.Label();
            this.lbl_Uf = new System.Windows.Forms.Label();
            this.lbl_Cidade = new System.Windows.Forms.Label();
            this.lbl_Endereco = new System.Windows.Forms.Label();
            this.lbl_Numero = new System.Windows.Forms.Label();
            this.lbl_Complemento = new System.Windows.Forms.Label();
            this.lbl_Bairro = new System.Windows.Forms.Label();
            this.lbl_Pais = new System.Windows.Forms.Label();
            this.lbl_Clientedesde = new System.Windows.Forms.Label();
            this.lbl_Foneresidencial = new System.Windows.Forms.Label();
            this.lbl_Fonecomercial = new System.Windows.Forms.Label();
            this.lbl_Celular = new System.Windows.Forms.Label();
            this.lbl_Email = new System.Windows.Forms.Label();
            this.txt_Codigo = new System.Windows.Forms.TextBox();
            this.txt_Cpf = new System.Windows.Forms.TextBox();
            this.txt_Primeironome = new System.Windows.Forms.TextBox();
            this.txt_Nome = new System.Windows.Forms.TextBox();
            this.txtRg = new System.Windows.Forms.TextBox();
            this.txt_Orgaoexp = new System.Windows.Forms.TextBox();
            this.txt_Nomedopai = new System.Windows.Forms.TextBox();
            this.txt_Nomedamae = new System.Windows.Forms.TextBox();
            this.txt_Cep = new System.Windows.Forms.TextBox();
            this.txtRuaendereco = new System.Windows.Forms.TextBox();
            this.txt_Numeroendereco = new System.Windows.Forms.TextBox();
            this.txt_Complemento = new System.Windows.Forms.TextBox();
            this.txt_Bairro = new System.Windows.Forms.TextBox();
            this.txt_Foneresidencial = new System.Windows.Forms.TextBox();
            this.txt_Fonecomercial = new System.Windows.Forms.TextBox();
            this.txt_celular = new System.Windows.Forms.TextBox();
            this.txt_Email = new System.Windows.Forms.TextBox();
            this.txt_Dddcelular = new System.Windows.Forms.TextBox();
            this.txt_Dddcomercial = new System.Windows.Forms.TextBox();
            this.txt_Dddresidencial = new System.Windows.Forms.TextBox();
            this.dtp_Datanasc = new System.Windows.Forms.DateTimePicker();
            this.dtp_Clientedesde = new System.Windows.Forms.DateTimePicker();
            this.cmbx_Categoria = new System.Windows.Forms.ComboBox();
            this.cmbx_Sexo = new System.Windows.Forms.ComboBox();
            this.cmbx_Uf = new System.Windows.Forms.ComboBox();
            this.cmbx_Cidade = new System.Windows.Forms.ComboBox();
            this.cmbx_Endereco = new System.Windows.Forms.ComboBox();
            this.cmbx_Pais = new System.Windows.Forms.ComboBox();
            this.dtg_Listar = new System.Windows.Forms.DataGridView();
            this.btn_Localizar = new System.Windows.Forms.Button();
            this.btn_Incluir = new System.Windows.Forms.Button();
            this.btn_Alterar = new System.Windows.Forms.Button();
            this.btn_Cancelar = new System.Windows.Forms.Button();
            this.btn_Visualizar = new System.Windows.Forms.Button();
            this.btn_Excluir = new System.Windows.Forms.Button();
            this.btn_Gravar = new System.Windows.Forms.Button();
            this.btn_Sair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Listar)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Nomecliente
            // 
            this.lbl_Nomecliente.AutoSize = true;
            this.lbl_Nomecliente.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Nomecliente.Location = new System.Drawing.Point(30, 9);
            this.lbl_Nomecliente.Name = "lbl_Nomecliente";
            this.lbl_Nomecliente.Size = new System.Drawing.Size(128, 15);
            this.lbl_Nomecliente.TabIndex = 0;
            this.lbl_Nomecliente.Text = "Informações do cliente";
            // 
            // lbl_Cpf
            // 
            this.lbl_Cpf.AutoSize = true;
            this.lbl_Cpf.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Cpf.Location = new System.Drawing.Point(201, 66);
            this.lbl_Cpf.Name = "lbl_Cpf";
            this.lbl_Cpf.Size = new System.Drawing.Size(33, 15);
            this.lbl_Cpf.TabIndex = 1;
            this.lbl_Cpf.Text = "CPF*";
            // 
            // lbl_Codigo
            // 
            this.lbl_Codigo.AutoSize = true;
            this.lbl_Codigo.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Codigo.Location = new System.Drawing.Point(68, 66);
            this.lbl_Codigo.Name = "lbl_Codigo";
            this.lbl_Codigo.Size = new System.Drawing.Size(46, 15);
            this.lbl_Codigo.TabIndex = 2;
            this.lbl_Codigo.Text = "Código";
            // 
            // lbl_Categoria
            // 
            this.lbl_Categoria.AutoSize = true;
            this.lbl_Categoria.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Categoria.Location = new System.Drawing.Point(332, 66);
            this.lbl_Categoria.Name = "lbl_Categoria";
            this.lbl_Categoria.Size = new System.Drawing.Size(66, 15);
            this.lbl_Categoria.TabIndex = 3;
            this.lbl_Categoria.Text = "Categoria*";
            // 
            // lbl_Primeironome
            // 
            this.lbl_Primeironome.AutoSize = true;
            this.lbl_Primeironome.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Primeironome.Location = new System.Drawing.Point(21, 109);
            this.lbl_Primeironome.Name = "lbl_Primeironome";
            this.lbl_Primeironome.Size = new System.Drawing.Size(93, 15);
            this.lbl_Primeironome.TabIndex = 4;
            this.lbl_Primeironome.Text = "Primeiro nome*";
            // 
            // lbl_Nome
            // 
            this.lbl_Nome.AutoSize = true;
            this.lbl_Nome.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Nome.Location = new System.Drawing.Point(332, 109);
            this.lbl_Nome.Name = "lbl_Nome";
            this.lbl_Nome.Size = new System.Drawing.Size(45, 15);
            this.lbl_Nome.TabIndex = 5;
            this.lbl_Nome.Text = "Nome*";
            // 
            // lbl_Datanasc
            // 
            this.lbl_Datanasc.AutoSize = true;
            this.lbl_Datanasc.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Datanasc.Location = new System.Drawing.Point(46, 150);
            this.lbl_Datanasc.Name = "lbl_Datanasc";
            this.lbl_Datanasc.Size = new System.Drawing.Size(68, 15);
            this.lbl_Datanasc.TabIndex = 6;
            this.lbl_Datanasc.Text = "Data Nasc*";
            // 
            // lbl_Sexo
            // 
            this.lbl_Sexo.AutoSize = true;
            this.lbl_Sexo.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Sexo.Location = new System.Drawing.Point(218, 150);
            this.lbl_Sexo.Name = "lbl_Sexo";
            this.lbl_Sexo.Size = new System.Drawing.Size(37, 15);
            this.lbl_Sexo.TabIndex = 7;
            this.lbl_Sexo.Text = "Sexo*";
            // 
            // lbl_Rg
            // 
            this.lbl_Rg.AutoSize = true;
            this.lbl_Rg.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Rg.Location = new System.Drawing.Point(332, 150);
            this.lbl_Rg.Name = "lbl_Rg";
            this.lbl_Rg.Size = new System.Drawing.Size(22, 15);
            this.lbl_Rg.TabIndex = 8;
            this.lbl_Rg.Text = "RG";
            // 
            // lbl_Orgaoexp
            // 
            this.lbl_Orgaoexp.AutoSize = true;
            this.lbl_Orgaoexp.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Orgaoexp.Location = new System.Drawing.Point(497, 150);
            this.lbl_Orgaoexp.Name = "lbl_Orgaoexp";
            this.lbl_Orgaoexp.Size = new System.Drawing.Size(67, 15);
            this.lbl_Orgaoexp.TabIndex = 9;
            this.lbl_Orgaoexp.Text = "Orgão Exp.";
            // 
            // lbl_Nomedopai
            // 
            this.lbl_Nomedopai.AutoSize = true;
            this.lbl_Nomedopai.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Nomedopai.Location = new System.Drawing.Point(37, 192);
            this.lbl_Nomedopai.Name = "lbl_Nomedopai";
            this.lbl_Nomedopai.Size = new System.Drawing.Size(77, 15);
            this.lbl_Nomedopai.TabIndex = 10;
            this.lbl_Nomedopai.Text = "Nome do Pai";
            // 
            // lbl_Nomedamae
            // 
            this.lbl_Nomedamae.AutoSize = true;
            this.lbl_Nomedamae.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Nomedamae.Location = new System.Drawing.Point(26, 236);
            this.lbl_Nomedamae.Name = "lbl_Nomedamae";
            this.lbl_Nomedamae.Size = new System.Drawing.Size(88, 15);
            this.lbl_Nomedamae.TabIndex = 11;
            this.lbl_Nomedamae.Text = "Nome da Mãe*";
            // 
            // lbl_Cep
            // 
            this.lbl_Cep.AutoSize = true;
            this.lbl_Cep.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Cep.Location = new System.Drawing.Point(81, 287);
            this.lbl_Cep.Name = "lbl_Cep";
            this.lbl_Cep.Size = new System.Drawing.Size(33, 15);
            this.lbl_Cep.TabIndex = 12;
            this.lbl_Cep.Text = "CEP*";
            // 
            // lbl_Uf
            // 
            this.lbl_Uf.AutoSize = true;
            this.lbl_Uf.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Uf.Location = new System.Drawing.Point(218, 287);
            this.lbl_Uf.Name = "lbl_Uf";
            this.lbl_Uf.Size = new System.Drawing.Size(26, 15);
            this.lbl_Uf.TabIndex = 13;
            this.lbl_Uf.Text = "UF*";
            // 
            // lbl_Cidade
            // 
            this.lbl_Cidade.AutoSize = true;
            this.lbl_Cidade.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Cidade.Location = new System.Drawing.Point(332, 287);
            this.lbl_Cidade.Name = "lbl_Cidade";
            this.lbl_Cidade.Size = new System.Drawing.Size(50, 15);
            this.lbl_Cidade.TabIndex = 14;
            this.lbl_Cidade.Text = "Cidade*";
            // 
            // lbl_Endereco
            // 
            this.lbl_Endereco.AutoSize = true;
            this.lbl_Endereco.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Endereco.Location = new System.Drawing.Point(53, 330);
            this.lbl_Endereco.Name = "lbl_Endereco";
            this.lbl_Endereco.Size = new System.Drawing.Size(61, 15);
            this.lbl_Endereco.TabIndex = 15;
            this.lbl_Endereco.Text = "Endereço*";
            // 
            // lbl_Numero
            // 
            this.lbl_Numero.AutoSize = true;
            this.lbl_Numero.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Numero.Location = new System.Drawing.Point(57, 370);
            this.lbl_Numero.Name = "lbl_Numero";
            this.lbl_Numero.Size = new System.Drawing.Size(57, 15);
            this.lbl_Numero.TabIndex = 16;
            this.lbl_Numero.Text = "Numero*";
            // 
            // lbl_Complemento
            // 
            this.lbl_Complemento.AutoSize = true;
            this.lbl_Complemento.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Complemento.Location = new System.Drawing.Point(218, 370);
            this.lbl_Complemento.Name = "lbl_Complemento";
            this.lbl_Complemento.Size = new System.Drawing.Size(84, 15);
            this.lbl_Complemento.TabIndex = 17;
            this.lbl_Complemento.Text = "Complemento";
            // 
            // lbl_Bairro
            // 
            this.lbl_Bairro.AutoSize = true;
            this.lbl_Bairro.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Bairro.Location = new System.Drawing.Point(402, 370);
            this.lbl_Bairro.Name = "lbl_Bairro";
            this.lbl_Bairro.Size = new System.Drawing.Size(46, 15);
            this.lbl_Bairro.TabIndex = 18;
            this.lbl_Bairro.Text = "Bairro*";
            // 
            // lbl_Pais
            // 
            this.lbl_Pais.AutoSize = true;
            this.lbl_Pais.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Pais.Location = new System.Drawing.Point(80, 417);
            this.lbl_Pais.Name = "lbl_Pais";
            this.lbl_Pais.Size = new System.Drawing.Size(34, 15);
            this.lbl_Pais.TabIndex = 19;
            this.lbl_Pais.Text = "País*";
            // 
            // lbl_Clientedesde
            // 
            this.lbl_Clientedesde.AutoSize = true;
            this.lbl_Clientedesde.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Clientedesde.Location = new System.Drawing.Point(497, 417);
            this.lbl_Clientedesde.Name = "lbl_Clientedesde";
            this.lbl_Clientedesde.Size = new System.Drawing.Size(80, 15);
            this.lbl_Clientedesde.TabIndex = 20;
            this.lbl_Clientedesde.Text = "Cliente Desde";
            // 
            // lbl_Foneresidencial
            // 
            this.lbl_Foneresidencial.AutoSize = true;
            this.lbl_Foneresidencial.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Foneresidencial.Location = new System.Drawing.Point(19, 463);
            this.lbl_Foneresidencial.Name = "lbl_Foneresidencial";
            this.lbl_Foneresidencial.Size = new System.Drawing.Size(95, 15);
            this.lbl_Foneresidencial.TabIndex = 21;
            this.lbl_Foneresidencial.Text = "Fone Residencial";
            // 
            // lbl_Fonecomercial
            // 
            this.lbl_Fonecomercial.AutoSize = true;
            this.lbl_Fonecomercial.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Fonecomercial.Location = new System.Drawing.Point(263, 463);
            this.lbl_Fonecomercial.Name = "lbl_Fonecomercial";
            this.lbl_Fonecomercial.Size = new System.Drawing.Size(91, 15);
            this.lbl_Fonecomercial.TabIndex = 22;
            this.lbl_Fonecomercial.Text = "Fone Comercial";
            // 
            // lbl_Celular
            // 
            this.lbl_Celular.AutoSize = true;
            this.lbl_Celular.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Celular.Location = new System.Drawing.Point(497, 463);
            this.lbl_Celular.Name = "lbl_Celular";
            this.lbl_Celular.Size = new System.Drawing.Size(46, 15);
            this.lbl_Celular.TabIndex = 23;
            this.lbl_Celular.Text = "Celular";
            // 
            // lbl_Email
            // 
            this.lbl_Email.AutoSize = true;
            this.lbl_Email.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point);
            this.lbl_Email.Location = new System.Drawing.Point(73, 510);
            this.lbl_Email.Name = "lbl_Email";
            this.lbl_Email.Size = new System.Drawing.Size(41, 15);
            this.lbl_Email.TabIndex = 24;
            this.lbl_Email.Text = "E-Mail";
            // 
            // txt_Codigo
            // 
            this.txt_Codigo.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Codigo.Location = new System.Drawing.Point(120, 63);
            this.txt_Codigo.Name = "txt_Codigo";
            this.txt_Codigo.Size = new System.Drawing.Size(75, 23);
            this.txt_Codigo.TabIndex = 25;
            this.txt_Codigo.Text = "105710";
            // 
            // txt_Cpf
            // 
            this.txt_Cpf.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Cpf.Location = new System.Drawing.Point(240, 63);
            this.txt_Cpf.Name = "txt_Cpf";
            this.txt_Cpf.Size = new System.Drawing.Size(86, 23);
            this.txt_Cpf.TabIndex = 26;
            this.txt_Cpf.Text = "411356";
            // 
            // txt_Primeironome
            // 
            this.txt_Primeironome.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Primeironome.Location = new System.Drawing.Point(120, 106);
            this.txt_Primeironome.Name = "txt_Primeironome";
            this.txt_Primeironome.Size = new System.Drawing.Size(206, 23);
            this.txt_Primeironome.TabIndex = 27;
            this.txt_Primeironome.Text = "KATIA";
            // 
            // txt_Nome
            // 
            this.txt_Nome.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Nome.Location = new System.Drawing.Point(383, 109);
            this.txt_Nome.Name = "txt_Nome";
            this.txt_Nome.Size = new System.Drawing.Size(302, 23);
            this.txt_Nome.TabIndex = 28;
            this.txt_Nome.Text = "KATIA CRISTINA";
            // 
            // txtRg
            // 
            this.txtRg.BackColor = System.Drawing.SystemColors.Info;
            this.txtRg.Location = new System.Drawing.Point(360, 147);
            this.txtRg.Name = "txtRg";
            this.txtRg.Size = new System.Drawing.Size(131, 23);
            this.txtRg.TabIndex = 29;
            this.txtRg.Text = "22433";
            // 
            // txt_Orgaoexp
            // 
            this.txt_Orgaoexp.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Orgaoexp.Location = new System.Drawing.Point(570, 147);
            this.txt_Orgaoexp.Name = "txt_Orgaoexp";
            this.txt_Orgaoexp.Size = new System.Drawing.Size(115, 23);
            this.txt_Orgaoexp.TabIndex = 30;
            // 
            // txt_Nomedopai
            // 
            this.txt_Nomedopai.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Nomedopai.Location = new System.Drawing.Point(120, 189);
            this.txt_Nomedopai.Name = "txt_Nomedopai";
            this.txt_Nomedopai.Size = new System.Drawing.Size(565, 23);
            this.txt_Nomedopai.TabIndex = 31;
            // 
            // txt_Nomedamae
            // 
            this.txt_Nomedamae.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Nomedamae.Location = new System.Drawing.Point(120, 233);
            this.txt_Nomedamae.Name = "txt_Nomedamae";
            this.txt_Nomedamae.Size = new System.Drawing.Size(559, 23);
            this.txt_Nomedamae.TabIndex = 32;
            this.txt_Nomedamae.Text = ".";
            // 
            // txt_Cep
            // 
            this.txt_Cep.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Cep.Location = new System.Drawing.Point(120, 284);
            this.txt_Cep.Name = "txt_Cep";
            this.txt_Cep.Size = new System.Drawing.Size(92, 23);
            this.txt_Cep.TabIndex = 33;
            this.txt_Cep.Text = "80540-220";
            // 
            // txtRuaendereco
            // 
            this.txtRuaendereco.BackColor = System.Drawing.SystemColors.Info;
            this.txtRuaendereco.Location = new System.Drawing.Point(240, 327);
            this.txtRuaendereco.Name = "txtRuaendereco";
            this.txtRuaendereco.Size = new System.Drawing.Size(445, 23);
            this.txtRuaendereco.TabIndex = 34;
            this.txtRuaendereco.Text = "RUA EMILIO CORNELSEN";
            // 
            // txt_Numeroendereco
            // 
            this.txt_Numeroendereco.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Numeroendereco.Location = new System.Drawing.Point(120, 367);
            this.txt_Numeroendereco.Name = "txt_Numeroendereco";
            this.txt_Numeroendereco.Size = new System.Drawing.Size(92, 23);
            this.txt_Numeroendereco.TabIndex = 35;
            this.txt_Numeroendereco.Text = "301";
            this.txt_Numeroendereco.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // txt_Complemento
            // 
            this.txt_Complemento.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Complemento.Location = new System.Drawing.Point(302, 367);
            this.txt_Complemento.Name = "txt_Complemento";
            this.txt_Complemento.Size = new System.Drawing.Size(96, 23);
            this.txt_Complemento.TabIndex = 36;
            // 
            // txt_Bairro
            // 
            this.txt_Bairro.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Bairro.Location = new System.Drawing.Point(454, 367);
            this.txt_Bairro.Name = "txt_Bairro";
            this.txt_Bairro.Size = new System.Drawing.Size(231, 23);
            this.txt_Bairro.TabIndex = 37;
            this.txt_Bairro.Text = "AHÚ";
            // 
            // txt_Foneresidencial
            // 
            this.txt_Foneresidencial.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Foneresidencial.Location = new System.Drawing.Point(154, 460);
            this.txt_Foneresidencial.Name = "txt_Foneresidencial";
            this.txt_Foneresidencial.Size = new System.Drawing.Size(103, 23);
            this.txt_Foneresidencial.TabIndex = 39;
            // 
            // txt_Fonecomercial
            // 
            this.txt_Fonecomercial.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Fonecomercial.Location = new System.Drawing.Point(394, 460);
            this.txt_Fonecomercial.Name = "txt_Fonecomercial";
            this.txt_Fonecomercial.Size = new System.Drawing.Size(97, 23);
            this.txt_Fonecomercial.TabIndex = 41;
            // 
            // txt_celular
            // 
            this.txt_celular.BackColor = System.Drawing.SystemColors.Info;
            this.txt_celular.Location = new System.Drawing.Point(583, 460);
            this.txt_celular.Name = "txt_celular";
            this.txt_celular.Size = new System.Drawing.Size(102, 23);
            this.txt_celular.TabIndex = 43;
            // 
            // txt_Email
            // 
            this.txt_Email.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Email.Location = new System.Drawing.Point(120, 507);
            this.txt_Email.Name = "txt_Email";
            this.txt_Email.Size = new System.Drawing.Size(565, 23);
            this.txt_Email.TabIndex = 44;
            this.txt_Email.Text = "ppkr@uol.com.br";
            // 
            // txt_Dddcelular
            // 
            this.txt_Dddcelular.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Dddcelular.Location = new System.Drawing.Point(549, 460);
            this.txt_Dddcelular.Name = "txt_Dddcelular";
            this.txt_Dddcelular.Size = new System.Drawing.Size(28, 23);
            this.txt_Dddcelular.TabIndex = 46;
            this.txt_Dddcelular.Text = "041";
            // 
            // txt_Dddcomercial
            // 
            this.txt_Dddcomercial.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Dddcomercial.Location = new System.Drawing.Point(360, 460);
            this.txt_Dddcomercial.Name = "txt_Dddcomercial";
            this.txt_Dddcomercial.Size = new System.Drawing.Size(28, 23);
            this.txt_Dddcomercial.TabIndex = 47;
            // 
            // txt_Dddresidencial
            // 
            this.txt_Dddresidencial.BackColor = System.Drawing.SystemColors.Info;
            this.txt_Dddresidencial.Location = new System.Drawing.Point(120, 460);
            this.txt_Dddresidencial.Name = "txt_Dddresidencial";
            this.txt_Dddresidencial.Size = new System.Drawing.Size(28, 23);
            this.txt_Dddresidencial.TabIndex = 48;
            // 
            // dtp_Datanasc
            // 
            this.dtp_Datanasc.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Datanasc.Location = new System.Drawing.Point(120, 147);
            this.dtp_Datanasc.Name = "dtp_Datanasc";
            this.dtp_Datanasc.Size = new System.Drawing.Size(92, 23);
            this.dtp_Datanasc.TabIndex = 49;
            this.dtp_Datanasc.Value = new System.DateTime(2023, 2, 13, 0, 0, 0, 0);
            // 
            // dtp_Clientedesde
            // 
            this.dtp_Clientedesde.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp_Clientedesde.Location = new System.Drawing.Point(583, 411);
            this.dtp_Clientedesde.Name = "dtp_Clientedesde";
            this.dtp_Clientedesde.Size = new System.Drawing.Size(102, 23);
            this.dtp_Clientedesde.TabIndex = 50;
            this.dtp_Clientedesde.Value = new System.DateTime(2023, 2, 13, 0, 0, 0, 0);
            // 
            // cmbx_Categoria
            // 
            this.cmbx_Categoria.BackColor = System.Drawing.SystemColors.Info;
            this.cmbx_Categoria.FormattingEnabled = true;
            this.cmbx_Categoria.Items.AddRange(new object[] {
            "ATENDIMENTO NORMAL"});
            this.cmbx_Categoria.Location = new System.Drawing.Point(404, 63);
            this.cmbx_Categoria.Name = "cmbx_Categoria";
            this.cmbx_Categoria.Size = new System.Drawing.Size(275, 23);
            this.cmbx_Categoria.TabIndex = 51;
            // 
            // cmbx_Sexo
            // 
            this.cmbx_Sexo.BackColor = System.Drawing.SystemColors.Info;
            this.cmbx_Sexo.FormattingEnabled = true;
            this.cmbx_Sexo.Items.AddRange(new object[] {
            "M",
            "F"});
            this.cmbx_Sexo.Location = new System.Drawing.Point(258, 147);
            this.cmbx_Sexo.Name = "cmbx_Sexo";
            this.cmbx_Sexo.Size = new System.Drawing.Size(68, 23);
            this.cmbx_Sexo.TabIndex = 52;
            // 
            // cmbx_Uf
            // 
            this.cmbx_Uf.BackColor = System.Drawing.SystemColors.Info;
            this.cmbx_Uf.FormattingEnabled = true;
            this.cmbx_Uf.Items.AddRange(new object[] {
            "PR"});
            this.cmbx_Uf.Location = new System.Drawing.Point(250, 284);
            this.cmbx_Uf.Name = "cmbx_Uf";
            this.cmbx_Uf.Size = new System.Drawing.Size(76, 23);
            this.cmbx_Uf.TabIndex = 53;
            // 
            // cmbx_Cidade
            // 
            this.cmbx_Cidade.BackColor = System.Drawing.SystemColors.Info;
            this.cmbx_Cidade.FormattingEnabled = true;
            this.cmbx_Cidade.Items.AddRange(new object[] {
            "CURITIBA"});
            this.cmbx_Cidade.Location = new System.Drawing.Point(383, 284);
            this.cmbx_Cidade.Name = "cmbx_Cidade";
            this.cmbx_Cidade.Size = new System.Drawing.Size(296, 23);
            this.cmbx_Cidade.TabIndex = 54;
            // 
            // cmbx_Endereco
            // 
            this.cmbx_Endereco.BackColor = System.Drawing.SystemColors.Info;
            this.cmbx_Endereco.FormattingEnabled = true;
            this.cmbx_Endereco.Items.AddRange(new object[] {
            "OUTROS"});
            this.cmbx_Endereco.Location = new System.Drawing.Point(120, 327);
            this.cmbx_Endereco.Name = "cmbx_Endereco";
            this.cmbx_Endereco.Size = new System.Drawing.Size(114, 23);
            this.cmbx_Endereco.TabIndex = 55;
            // 
            // cmbx_Pais
            // 
            this.cmbx_Pais.BackColor = System.Drawing.SystemColors.Info;
            this.cmbx_Pais.FormattingEnabled = true;
            this.cmbx_Pais.Items.AddRange(new object[] {
            "BRASIL"});
            this.cmbx_Pais.Location = new System.Drawing.Point(120, 414);
            this.cmbx_Pais.Name = "cmbx_Pais";
            this.cmbx_Pais.Size = new System.Drawing.Size(371, 23);
            this.cmbx_Pais.TabIndex = 56;
            // 
            // dtg_Listar
            // 
            this.dtg_Listar.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_Listar.Location = new System.Drawing.Point(17, 557);
            this.dtg_Listar.Name = "dtg_Listar";
            this.dtg_Listar.RowTemplate.Height = 25;
            this.dtg_Listar.Size = new System.Drawing.Size(668, 150);
            this.dtg_Listar.TabIndex = 57;
            // 
            // btn_Localizar
            // 
            this.btn_Localizar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Localizar.ForeColor = System.Drawing.Color.Navy;
            this.btn_Localizar.Location = new System.Drawing.Point(17, 754);
            this.btn_Localizar.Name = "btn_Localizar";
            this.btn_Localizar.Size = new System.Drawing.Size(149, 31);
            this.btn_Localizar.TabIndex = 58;
            this.btn_Localizar.Text = "Localizar";
            this.btn_Localizar.UseVisualStyleBackColor = true;
            this.btn_Localizar.Click += new System.EventHandler(this.btn_Localizar_Click);
            // 
            // btn_Incluir
            // 
            this.btn_Incluir.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Incluir.ForeColor = System.Drawing.Color.Navy;
            this.btn_Incluir.Location = new System.Drawing.Point(188, 754);
            this.btn_Incluir.Name = "btn_Incluir";
            this.btn_Incluir.Size = new System.Drawing.Size(149, 31);
            this.btn_Incluir.TabIndex = 62;
            this.btn_Incluir.Text = "Incluir";
            this.btn_Incluir.UseVisualStyleBackColor = true;
            this.btn_Incluir.Click += new System.EventHandler(this.btn_Incluir_Click);
            // 
            // btn_Alterar
            // 
            this.btn_Alterar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Alterar.ForeColor = System.Drawing.Color.Navy;
            this.btn_Alterar.Location = new System.Drawing.Point(360, 754);
            this.btn_Alterar.Name = "btn_Alterar";
            this.btn_Alterar.Size = new System.Drawing.Size(149, 31);
            this.btn_Alterar.TabIndex = 63;
            this.btn_Alterar.Text = "Alterar";
            this.btn_Alterar.UseVisualStyleBackColor = true;
            this.btn_Alterar.Click += new System.EventHandler(this.btn_Alterar_Click);
            // 
            // btn_Cancelar
            // 
            this.btn_Cancelar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Cancelar.ForeColor = System.Drawing.Color.Navy;
            this.btn_Cancelar.Location = new System.Drawing.Point(536, 754);
            this.btn_Cancelar.Name = "btn_Cancelar";
            this.btn_Cancelar.Size = new System.Drawing.Size(149, 31);
            this.btn_Cancelar.TabIndex = 64;
            this.btn_Cancelar.Text = "Cancelar";
            this.btn_Cancelar.UseVisualStyleBackColor = true;
            this.btn_Cancelar.Click += new System.EventHandler(this.btn_Cancelar_Click);
            // 
            // btn_Visualizar
            // 
            this.btn_Visualizar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Visualizar.ForeColor = System.Drawing.Color.Navy;
            this.btn_Visualizar.Location = new System.Drawing.Point(17, 813);
            this.btn_Visualizar.Name = "btn_Visualizar";
            this.btn_Visualizar.Size = new System.Drawing.Size(149, 31);
            this.btn_Visualizar.TabIndex = 65;
            this.btn_Visualizar.Text = "Visualizar";
            this.btn_Visualizar.UseVisualStyleBackColor = true;
            this.btn_Visualizar.Click += new System.EventHandler(this.btn_Visualizar_Click);
            // 
            // btn_Excluir
            // 
            this.btn_Excluir.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Excluir.ForeColor = System.Drawing.Color.Navy;
            this.btn_Excluir.Location = new System.Drawing.Point(188, 813);
            this.btn_Excluir.Name = "btn_Excluir";
            this.btn_Excluir.Size = new System.Drawing.Size(149, 31);
            this.btn_Excluir.TabIndex = 66;
            this.btn_Excluir.Text = "Excluir";
            this.btn_Excluir.UseVisualStyleBackColor = true;
            this.btn_Excluir.Click += new System.EventHandler(this.btn_Excluir_Click);
            // 
            // btn_Gravar
            // 
            this.btn_Gravar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Gravar.ForeColor = System.Drawing.Color.Navy;
            this.btn_Gravar.Location = new System.Drawing.Point(360, 813);
            this.btn_Gravar.Name = "btn_Gravar";
            this.btn_Gravar.Size = new System.Drawing.Size(149, 31);
            this.btn_Gravar.TabIndex = 67;
            this.btn_Gravar.Text = "Gravar";
            this.btn_Gravar.UseVisualStyleBackColor = true;
            this.btn_Gravar.Click += new System.EventHandler(this.btn_Gravar_Click);
            // 
            // btn_Sair
            // 
            this.btn_Sair.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_Sair.ForeColor = System.Drawing.Color.Navy;
            this.btn_Sair.Location = new System.Drawing.Point(536, 813);
            this.btn_Sair.Name = "btn_Sair";
            this.btn_Sair.Size = new System.Drawing.Size(149, 31);
            this.btn_Sair.TabIndex = 68;
            this.btn_Sair.Text = "Sair";
            this.btn_Sair.UseVisualStyleBackColor = true;
            this.btn_Sair.Click += new System.EventHandler(this.btn_Sair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange;
            this.ClientSize = new System.Drawing.Size(693, 881);
            this.Controls.Add(this.btn_Sair);
            this.Controls.Add(this.btn_Gravar);
            this.Controls.Add(this.btn_Excluir);
            this.Controls.Add(this.btn_Visualizar);
            this.Controls.Add(this.btn_Cancelar);
            this.Controls.Add(this.btn_Alterar);
            this.Controls.Add(this.btn_Incluir);
            this.Controls.Add(this.btn_Localizar);
            this.Controls.Add(this.dtg_Listar);
            this.Controls.Add(this.cmbx_Pais);
            this.Controls.Add(this.cmbx_Endereco);
            this.Controls.Add(this.cmbx_Cidade);
            this.Controls.Add(this.cmbx_Uf);
            this.Controls.Add(this.cmbx_Sexo);
            this.Controls.Add(this.cmbx_Categoria);
            this.Controls.Add(this.dtp_Clientedesde);
            this.Controls.Add(this.dtp_Datanasc);
            this.Controls.Add(this.txt_Dddresidencial);
            this.Controls.Add(this.txt_Dddcomercial);
            this.Controls.Add(this.txt_Dddcelular);
            this.Controls.Add(this.txt_Email);
            this.Controls.Add(this.txt_celular);
            this.Controls.Add(this.txt_Fonecomercial);
            this.Controls.Add(this.txt_Foneresidencial);
            this.Controls.Add(this.txt_Bairro);
            this.Controls.Add(this.txt_Complemento);
            this.Controls.Add(this.txt_Numeroendereco);
            this.Controls.Add(this.txtRuaendereco);
            this.Controls.Add(this.txt_Cep);
            this.Controls.Add(this.txt_Nomedamae);
            this.Controls.Add(this.txt_Nomedopai);
            this.Controls.Add(this.txt_Orgaoexp);
            this.Controls.Add(this.txtRg);
            this.Controls.Add(this.txt_Nome);
            this.Controls.Add(this.txt_Primeironome);
            this.Controls.Add(this.txt_Cpf);
            this.Controls.Add(this.txt_Codigo);
            this.Controls.Add(this.lbl_Email);
            this.Controls.Add(this.lbl_Celular);
            this.Controls.Add(this.lbl_Fonecomercial);
            this.Controls.Add(this.lbl_Foneresidencial);
            this.Controls.Add(this.lbl_Clientedesde);
            this.Controls.Add(this.lbl_Pais);
            this.Controls.Add(this.lbl_Bairro);
            this.Controls.Add(this.lbl_Complemento);
            this.Controls.Add(this.lbl_Numero);
            this.Controls.Add(this.lbl_Endereco);
            this.Controls.Add(this.lbl_Cidade);
            this.Controls.Add(this.lbl_Uf);
            this.Controls.Add(this.lbl_Cep);
            this.Controls.Add(this.lbl_Nomedamae);
            this.Controls.Add(this.lbl_Nomedopai);
            this.Controls.Add(this.lbl_Orgaoexp);
            this.Controls.Add(this.lbl_Rg);
            this.Controls.Add(this.lbl_Sexo);
            this.Controls.Add(this.lbl_Datanasc);
            this.Controls.Add(this.lbl_Nome);
            this.Controls.Add(this.lbl_Primeironome);
            this.Controls.Add(this.lbl_Categoria);
            this.Controls.Add(this.lbl_Codigo);
            this.Controls.Add(this.lbl_Cpf);
            this.Controls.Add(this.lbl_Nomecliente);
            this.Name = "Form1";
            this.Text = "Cadastro de Clientes";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_Listar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label lbl_Nomecliente;
        private Label lbl_Cpf;
        private Label lbl_Codigo;
        private Label lbl_Categoria;
        private Label lbl_Primeironome;
        private Label lbl_Nome;
        private Label lbl_Datanasc;
        private Label lbl_Sexo;
        private Label lbl_Rg;
        private Label lbl_Orgaoexp;
        private Label lbl_Nomedopai;
        private Label lbl_Nomedamae;
        private Label lbl_Cep;
        private Label lbl_Uf;
        private Label lbl_Cidade;
        private Label lbl_Endereco;
        private Label lbl_Numero;
        private Label lbl_Complemento;
        private Label lbl_Bairro;
        private Label lbl_Pais;
        private Label lbl_Clientedesde;
        private Label lbl_Foneresidencial;
        private Label lbl_Fonecomercial;
        private Label lbl_Celular;
        private Label lbl_Email;
        private TextBox txt_Codigo;
        private TextBox txt_Cpf;
        private TextBox txt_Primeironome;
        private TextBox txt_Nome;
        private TextBox txtRg;
        private TextBox txt_Orgaoexp;
        private TextBox txt_Nomedopai;
        private TextBox txt_Nomedamae;
        private TextBox txt_Cep;
        private TextBox txtRuaendereco;
        private TextBox txt_Numeroendereco;
        private TextBox txt_Complemento;
        private TextBox txt_Bairro;
        private TextBox txt_Foneresidencial;
        private TextBox txt_Fonecomercial;
        private TextBox txt_celular;
        private TextBox txt_Email;
        private TextBox txt_Dddcelular;
        private TextBox txt_Dddcomercial;
        private TextBox txt_Dddresidencial;
        private DateTimePicker dtp_Datanasc;
        private DateTimePicker dtp_Clientedesde;
        private ComboBox cmbx_Categoria;
        private ComboBox cmbx_Sexo;
        private ComboBox cmbx_Uf;
        private ComboBox cmbx_Cidade;
        private ComboBox cmbx_Endereco;
        private ComboBox cmbx_Pais;
        private DataGridView dtg_Listar;
        private Button btn_Localizar;
        private Button btn_Incluir;
        private Button btn_Alterar;
        private Button btn_Cancelar;
        private Button btn_Visualizar;
        private Button btn_Excluir;
        private Button btn_Gravar;
        private Button btn_Sair;
    }
}